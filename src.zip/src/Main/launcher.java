/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import game.display.Display;

/**
 * 
 * @author 8TITTIT8
 */
public class launcher {
    public static void main(String[] args) {
//        Game game = new Game("Hello!!!");
//        game.start();
        new Display("hello!");
    }
}
